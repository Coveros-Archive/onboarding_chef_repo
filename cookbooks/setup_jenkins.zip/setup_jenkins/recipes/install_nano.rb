# yum install nano
yum_package 'nano' do
	options "-y"
end