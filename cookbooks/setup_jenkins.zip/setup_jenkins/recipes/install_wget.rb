# yum install wget
yum_package 'wget' do
	options "-y"
end